# Anomaliler
- Cin - Revenant
***
- Suretçalar - Changeling
***
- Uzay Korsanları - Pirate
***
- Kültistler - Cults
***
- Heretik - Heretic
***
- Yabancı Form - Xenomorph
***
- Karabasan - Nightmare
***
- Alıkoyucu - Abducator
***

# Türler
- Pullusoy - Lizard
***
- İnsan - Human
***
- Etheryal - Ethereal
***
- Araknid - Arachnid
***
- Kedigilli - Felinid
***
- Sinek Birey - Flypeople
***
- Jel Birey - Jellypeople
***
- İpliksoylu - Moth
***
- Çimen Birey - Podman

# Hükümet ve Organizasyonlar
- Büyücüler Federasyonu - Wizard Federation
***
- Sendika - Syndicate
***
- Örümcek Klanı - Spider Clan
***

# DİĞER
- Merkezi Komuta - Centcom
***
