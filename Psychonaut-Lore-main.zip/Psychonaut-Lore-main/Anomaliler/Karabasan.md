> "Karanlık Ebedidir. Ancak insanlık değil!"
***

# Karabasanlar

Karabasanlar çoğu zaman kişilerin yalnız olarak bulunduğu maintler, dormslar gibi dış ortamlardan uzak ortamlarda insanların korku ve kaygısının oluşması sonucunda meydana gelir. Karabasanlar insanların temel korkuları olan yalnızlık ve karanlık korkusu gibi dürtülerden beslenmesiyle bilinir, Karabasanlar insanlar gibi konuşmasını bilmesinin dışında merhamet, üzüntü gibi duyguları beslediği rahatlıkla görülebilir.

Karanbasanlar ilk ortaya çıkışlarından itibaren (Tarih belirsiz muhtemel 23 yy. ortaları) konuşularak anlaşılmaya çalışılmış fakat bir türlü başarılı olunamamıştır.

# Karabasan- Madenci Çatışması

Nanotrasen maden tesisleri kurmaya başladığından beri madenlerde küçük küçük Karabasan tapınaklarına rast gelmiş ve Nanotrasen madencileri ile Karabasanlar arasında sürekli bir mücadele meydana gelmiştir. Nanotrasen yetkilileri ise bu durum günün sonunda madencileri tarafından Karabasan tapınaklarını yıktıkları için bu durum pekte önemli karşılanmamıştır.

![Ekran görüntüsü 2024-06-17 222557](https://github.com/Oynumt1/Psychonaut-Lore/assets/151470732/0d1bfc7a-5307-4fba-8936-7629749f939c)


*Karabasan-Madenci çatışmasını simgeleyen bir fotoğraf*


# Karanlığın Tanrısı Nyx

Ayrıca Karabasanların taptığı tanrının ismi Nyx'dır. Bu isim Yunan Mitolojisinde yer alan Gecenin ve Karanlığın Tanrıçası olarak bilinir.

Nyx'ın tam olarak şeklinin tanımı yapılamayan tanrıdır. Her ne kadar Karabasanlar Nyx'a tapıyor olsalar bile Nyx sadece Karabasanların tanrısı değildir. Çeşitli gezegenlerde insanlar, pullusoylar ve arkanidler dahi bu ırka tapabilen türlerdir. Nyx karanlıktan güç aldığından dolayı ibadetler sadece karanlık ortamlarda veyahut geceleri yapılabilir.

Bazı araştırmacılar tarafından Karabasanlar Nyx'ın yarattığı kullar bazen ise melekler olarak adlandırılır.
