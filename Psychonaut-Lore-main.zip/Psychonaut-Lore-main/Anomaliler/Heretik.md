> "İnsanlığın en eski duygusu korkudur ve korkuların en eskisi bilinmeyene karşı olandır. Korku artık unutulmuş, yutulmuş, parçalanmış. Fakat Mansus'un örtüsü zayıfladı. Onlara tekrar korkuyu tattıracağız..."
***

Uzayın derinliklerinde, kimsenin bilmediği karanlık ve antik bir sır gizlidir. Bu sır, insanın hayal gücünün ötesinde güçler barındırır ve sadece seçilmiş birkaç kişi tarafından anlaşılabilir. Bu kişiler, "Heretik" olarak bilinir.

"Heretik"ler, normal insanların aksine, yasaklanmış ve tehlikeli bilgilerin peşinden giderler. Onlar, evrenin karanlık köşelerinde saklanan eski tanrıların ve şeytani varlıkların fısıldadığı gizemli öğretileri takip ederler. Bu öğretiler, onları inanılmaz güçlere sahip kılar; ancak bu güçlerin bedeli ağırdır. Heretik, bu karanlık güçleri kullanarak kendini geliştirmeye ve nihai hedeflerine ulaşmaya çalışır.

Heretik'in yolculuğu, sıradan bir araştırmacının eski bir el yazmasını keşfetmesiyle başlar. Bu el yazması, kayıp bilgileri ve karanlık ritüelleri içeren bir kitaptır. Heretik, bu kitabın cazibesine kapılır ve içindeki bilgileri kullanarak güç kazanmaya başlar. Ancak bu güç, insanlıktan uzaklaşmasına ve gittikçe daha da karanlık bir yola sapmasına neden olur.


![image](https://github.com/Oynumt1/Psychonaut-Lore/assets/172262803/8831fdc5-d9c2-4a5a-8bd4-e6911d9ef26b)
