"Güvenlik Şefi Zen Işıkyıldızı bildiriyor, sanırım bu departmanda yolunda gitmeyen bazı şeyle-" * "ARBEDE SESLERİ, SES CIZIRTISI* " Yanlış alarm, her şey gayet yerli yerinde. İşinizin başına geri dönebilirsiniz." Kim ve nerde iletildiği bilinmeyen bir radyo iletisi.

İletinin sesli hali:


https://github.com/Oynumt1/Psychonaut-Lore/assets/151470732/154e6942-c46e-4d5b-9554-d81efcd492ae



***

Suretçalarlar insanlık uzayı keşif ettiğinden beri insanlığa bela bir sorun haline gelmiş ve bu sorunla başa çıkmak için alanında uzmanlar taktiksel savunma, saldırı metotları geliştirmiştir.

Suretçalarlar sülük böceği mantığı ile hareket eden bir yaratıktır, Suretçalar bazen bir düşen meteorun bazen ise bir hayvanın derisinin üzerinde kurbanını bekler halde olur. Suretçalar istediği şekilde bir organizma (Organizmanın karışık olması önemlidir; insan, pullusoy gibi.) üzerine yapışmayı becerirse çok kısa süre içerisinde beden üzerinde hakimiyet kurar ve organizmayı kendi emellei üzerinde hareket etmeye zorlar. Emelleri arasında insan öldürmek olan Suretçalarların davranışın asıl sebebi çeşitli gözlem yapan insanlar tarafından diğer Suretçalarlara kolaylık sağlamak için yaptığı tahmin edilir.

Suretçalarların aslen nereden geldiği bilinmemekle beraber arkasında çok fazla soru işareti bırakan bir anomali türüdür.

![Ekran görüntüsü 2024-06-17 235557](https://github.com/Oynumt1/Psychonaut-Lore/assets/151470732/9eeca009-ae19-4478-9612-f071baa7be59)

*Suretçaları temsil eden bir resim*
