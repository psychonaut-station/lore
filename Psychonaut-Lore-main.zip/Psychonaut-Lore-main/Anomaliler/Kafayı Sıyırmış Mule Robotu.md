> "Baylar, bu paketlerinin hepsini mule robotuna yükledi-"
***

https://github.com/Oynumt1/Psychonaut-Lore/assets/151470732/3685a26e-0377-4e4d-b9bd-62c7fd22cdda

LÜTFEN MULE ROBOTUNU BOZMA! İZİN VERME!

![image](https://github.com/Oynumt1/Psychonaut-Lore/assets/151470732/1bfe41e5-21fe-4b76-8062-4060242e7014)
