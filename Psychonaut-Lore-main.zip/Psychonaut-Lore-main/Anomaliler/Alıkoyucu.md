Alıkoyucular aslen kökenleri ve amaçları bilinmeyen değişik varlıklar olmalarıyla bilinir.

Alıkoyucular çeşitli mekanlara (Maden ve uzay istasyonları öncelikli) form değiştirerek ortam içerisinde yer alan bireylere bürünürler ve onlar gibi davranmaya çalışırlar. Fakat pekte başarılı oldukları söylenemez, sonuçta konuşma yetisi olmayan telepati ile konuşan üst düzey varlıklar.

İnsanları kaçırıp üzerinde deney yapan bu varlıklar bundan keyif alıyor gözükecek ki bunları yapmaya devam ediyorlar. Üzerinde deney yapılan denekler hakkında analizler yapıldığı vakit denekler kendilerine verilen rastgele görevler dahilinde ilerlemek zorunda hissediyorlar.
