Kaçaklar ve Avcılar istasyon içerisinde kovalamaca yaratan anomalilerden birisidir.

# Kaçaklar

Kaçaklar Terragov'un kırmızı listesinde aranmakta olan ve üzerine para ödülü koyulan yasadışı bireylerdir.

# Avcılar

"KANUN NAMINA YERİNDE DUR GENÇ ADAM!"
***

Avcılar Terragov'un kırmızı listesinde aranmakta olan ve üzerine para ödülü koyulan yasadışı bireyleri yakalamak için bireyleri yakalamaya çalışırlar. Genellikle bu kişiler bir yere bağlı olmayan kelle avcılarıdır.
