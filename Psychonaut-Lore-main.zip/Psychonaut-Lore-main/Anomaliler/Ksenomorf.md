> "SsSsSS SssSsSS sSSSSss SSsssSsSSsss!!"
***
# Temel
Ksenomorflar güçlü derileriyle ve duvar arkasını görebilecek kadar güçlü gözleriyle tanınsa bile o kadar basit canlılar değillerdir.

Ksenomorfların insanlarla tanışmaları insanlığın uzaya çıkıp plazmayı bulmasının ardından hemen sonra bir maden istasyonun Ksenomorflar tarafından ele geçirilmesiyle tanışılmıştır. Bu tanışmanın pekte sıcak olduğu söylenemediği için Terragov hükümeti bu kanlı maden istasyonunun sahipliğinin değişimini hiç hoş karşılanmamış olacak ki Terragov hükümeti TGMC adlı bir birlik kurmuş ve bu birliği sadece bu güçlü Ksenomorf'lara karşı mücadele etmesi için ayırmıştır.

# Türün Devamı

Ksenomorf'ların tek cinsiyeti dişi olmakla beraber nasıl türlerini devam ettireceklerini sizlere kısa bir şekilde anlatacağım:

Ksenomorf Kraliçesi tarafından yumurtlanan erkek dölleri (Bunlara biz yüzyutucu diyoruz) üretilir ardından ana rahmi görevi gören karışık organizmalara (İnsan, pulsoylu, maymun vb.) yerleştirir ve erkek dölleri vücudu dölleyerek yeni bir yavrunun (Her yavru dişi doğuyor) dünyaya gelmesine vesile olur.

# Hiyerarşi

Ksenomorf'lar içerisinde hiyerarşi bulunur, bu nasıl olacak diye sorarsanız:

Ksenomorf'lar larva olarak doğarlar ve bu şekilde büyürler. Doğdukları anda sarımsı bir renge sahip olan larvalar vakit geçtikçe kırmızılaşır ve yavaştan Kız Kardeş formuna bürünür.

Kız Kardeş formu larvadan sonra gelen ilk aşamadır. Kız Kardeş formu 3 gruba ayrılır:

- Avcılar

- İşçiler

- Gözcüler

**Avcılar**

Avcılar genel olarak yuvanın güvenliğini sağlamakla beraber yuvaya ana rahmi yerine geçen organizmaları getiren ksenomorf olmasıyla bilinir.

**İşçiler**

İşçiler yuvanın düzenliğini sağlar desek hiç yanlış olmaz. İşçiler genel olarak yuva için duvarları, yatakları ve çeşitli yuvaları hazırlar.

**Gözcüler**

Gözcüler yuva içerisi güvenliği sağlamak ve avcılara haber vermek amacıyla etrafı gözetlerler.

**Abla**

Abla Kız Kardeş Formundan sonra gelen diğer bir rütbe sayılabilir. Ablalar avcılar, gözcüler ve işçiler gibi özelliklerin bütününü barındırmakla beraber saldırma yetenekleri daha farklıdır.

**Kraliçe**

Kraliçe Abla formundan sonra gelen rütbe sayılabilir. Kraliçeler diğer bütün formların özelliklerini taşır ve daha fazlasını taşır, yuvayı yönetir, emir verir
