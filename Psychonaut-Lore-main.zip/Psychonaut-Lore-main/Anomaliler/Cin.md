> "Yeter artık! Ne cinmiş be? Din adamı ne işe yarıyor?"
Çarpılmaktan bezmiş doktorun radyodan bağırdı iletiler.
***

Cinler mitolojik çağlardan beri inanılan mistik canlılar olmasının yanı sıra elektriğin bulunmasının ardından mor silüetli cin söylemi halk arasında yaygınlaşmış dönemin din adamları buna çözüm bulmaya çalışmıştır. Bir zaman sonra din adamlarınına da görünnmeye başlamış ve din adamlarının bu cinden etkilenmediği anlaşılınca mücadele etme yöntemlerini keşfetme hızı artmıştır.

Bir süre cinlerle başa çıkmaya çalışan din adamları yaptıkları gözlemler sonucunda cinlerin ölü bireylerin ruhlarıyla beslendiği ve tuz, kutsal su gibi maddelerden zarar gördüğü fark edilmiştir. Bunun fark edilmesi üzerine bu bilgiler nesilden nesile aktarılmış 26. yüzyıla kadar ulaşmıştır.

Nanotrasen ise bu cinlerin mürettebatı rahatsız edebileceği tehlikesini de göze alarak istasyonlarına bir din adamı atamıştır.

![image0](https://github.com/Oynumt1/Psychonaut-Lore/assets/151470732/4c184448-bd85-4222-9c36-c20ff08744ef)
