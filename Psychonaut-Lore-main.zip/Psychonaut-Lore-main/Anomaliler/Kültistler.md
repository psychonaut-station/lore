> "Nar'Sie yükseliyor! Yüce Nar'Sie'nin şanını kanınla anacağım!"

https://github.com/Oynumt1/Psychonaut-Lore/assets/151470732/9f0637cd-517d-4b28-beb1-57a038fd3b83

***

Kültistler temel olarak ikiye ayrılsa bile şuan yaşayan kültler Kan Kültistleri olarak devam eder.

İlk olarak Kan Kültistlerinden bahsedelim.

# Kan Kültistleri - Nar'Sie

Kan Kültistleri Nar'Sie adında bir tanrıya tapan çoğu din adamı tarafından sapkın olarak karşılanan bir tarikattır... Ya da din mi demeliydim? Bu tarikatın ne zamandan beri var olduğu bilinmese bile bilinen tek şey Nar'Sie isimli tanrının eski insan uygarlıklarıdan beri tapılan bir varlı olmasıdır.

Kan Kültistleri kanlarından rünler çizerek çeşitli ayinler yaparlar ve diğer insanları tarikat üyesi yapmak için çizilen bu kanlı ründen yaparlar.

Kan Kültistleri yayılırken aralarında bir lider seçer ve bu lider sayesinde büyük ayinler gerçekleştirirler. Bu lider ayrıca Kan Kültistlerine öncülük eder.

Kan Kültistlerinin asıl hedefleri bulundukları mekanlara Nar'Sie adlı tanrıyı getirerek bedenlerini Nar'Sie'nin hizmetçisi olan varlıklara çevirmeye çalışırlar.
*O derece sapkınlık desene.*

![Narsie](https://github.com/Oynumt1/Psychonaut-Lore/assets/151470732/8efed722-2678-46ca-92ce-32a3fd75e443)


# Teknoloji Kültistleri - Rat'Var

Teknoloji Kültistleri kendilerine ait olan Cogs Şehri diye bir mekanda başlar asıl hedefleri yine Kan Külstileri gibi kendi tanrılarını çağırmak olsa bile bu meseleyi güçlerinden dolayı pek dert etmezler, ellerindeki güçler ile insanları kolaylıkla kendi tarikatlarına çekebilirler.

Teknoloji Kültistlerinin tanrısı olan Rat'Var, Nar'Sie ile verdiği savaş sonucu yenik düşmüş ve 13. Uzay İstasyonunun üzerinde kurulduğu bir gezegen olan Lavaland'e düşmüştür.

![Ratvar](https://github.com/Oynumt1/Psychonaut-Lore/assets/151470732/bf6cdcd2-008f-4973-9e94-47712a7bf802)

# İki Tarikatın Savaşı

Nar'Sie ile Rat'Var arasındaki savaş insanlığın elektriği bulmasından itibaren aralarında verdikleri savaş devam etmiştir. Nar'Sie'nin tarikatının evrende daha güçlenmesive alıcı bulması sonucunda Rat'Var, Nar'Sie'ye nazaran geri kalmış. Nar'Sie ile Rat'Var tam olarak nerede karşılantığı bilinmese bile 13. Uzay İstasyonu ile Güneş Sistemi arasındaki bölge içerisinde yer aldığı düşünülmektedir. Bu karşılaşmanın sonucunda Rat'Var ölmüş ve tarikatı dağılmıştır.
