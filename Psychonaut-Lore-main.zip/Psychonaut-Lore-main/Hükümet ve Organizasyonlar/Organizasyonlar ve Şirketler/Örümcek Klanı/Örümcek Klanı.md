> "Kişisel değil, evlat"
 -Uzay İstasyonu 11'in kaptanını öldürmek için gelen bir ninjanın kaptan odasında kayıt edilen tek iletisi.
***

Birkaç yüzyıldır varlığını sürdüren Örümcek Klanı tarikatımsı bir yapıya sahiptir. Örümcek Klanı kusursuz konuma gelmek ve Postmodern Uzay Bushido'sunu takip etmek için insan etinin bir tür büyütülmesini uygular.

Örümcek Klanının liderleri genellikle bir ölümlü için fazla yaşamış olan ustaları olarak seçilir.
*Bunun sebebi ise eski Japon geleneklerine dayanıyor*

Teknoloji açısından bir hayli gelişmiş olan bu klan son teknolojileri barındırır, sibernetik implantlar, dış iskelet donanımları, hiper kapasiteli bataryalar anladınız işte. İnsanlar bu teknoloji harikalığının sebebi konusunda ikiye bölünmüş görünüyor, kimileri Örümcek Klanının tersine mühendislik ile bu kadar iyi olduğunu düşünürken diğer kısım ise bu konuya şüpheci yaklaşıyor.
Her ne olursa olsun bu teknolojilerinin harika olduğunu değiştirmiyor!

Uzay Ninjaları uzayda yaptıkları yolculuklarla bilinmelerinin yanı sıra bu yolculuklarının çoğu zaman bir sebebi bulunur. Kimi ninja suikast düzenlemek için, kimi ninja ise klan içerisinde mevki kazanmak umuduyla bir yerlere baskın atmak için yol alır.

Uzay Ninjaları Nanotrasen'in istasyonlarına yaptığı baskınlarının sebebi genellikle istasyon hakkında bilgi toplamak, teknolojik aletler ve dataları kendi lehine kullanmak içindir.

Örümcek Klanının merkezi halen daha tahmin edilemese bile kendilerine insanlar bu konu hakkında tez üretmeye devam ediyor.
