# Cybersun Endüstrisi
Sendikanın bir numaralı kurumsal üyesidir. Tüketiciler için yüksek kalitede elektronik eşyalar, cyborglar, temel düzeyde sanal yapay zekalar üretir (Nanotrasen'in yeni teknolojisi dışında)

# Interdyne Eczacılık
Sendika içerisinde kurumsal bir üyedir. Sağlık sektörü için çeşitli kimyasallar üretmenin yanı sıra özel uyutucu modeller, protezler, organ baskı cihazları ve ameliyathaneler için cerrahi malzemeler üretir.

# Donk Anonim Şirketi
Sendika içerisinde kurumsal bir üyedir. Oyuncaklar, mekikler için çeşitli parçalar (yeri geldiği zaman mekik) ve mikrodalgaya koyduğunuz zaman hazır olan hazır yiyeccekler üretir.

# Waffle Limitet Şirketi
Sendika içerisinde kurumsal bir üyedir. Kahvaltılık yiyecekler üretir, aslında kara borsa için zaman zaman ateşli silahlar bile üretebilir.

Buraya kadar okuduğunuz şirketler sendika hizmetinde olmakla beraber şirket kurucuları genellikle Asya ve Avrupa kökenlidir.
-

# Apadyne Teknolojileri Şirketi
Askeri üretim gerçekleştirirler. Uzay gemileri için zırhlar, mekanik robotlar için gerekli parçalar, savaş için zırhlar ve yüksek patlayıcı malzemeleri üretir.

# Aussec Cephaneliği Şirketi
Askeri üretim gerçekleştirirler. Mühimmatlar, ateşli silahlar ve silah parçaları üretir. Bunlar genellikle ağır piyade birlikleri için uygundur.

# Scarborough Kolları Şirketi
Askeri üretim gerçekleştirirler. Mühimmatlar, ateşli silahlar ve silah parçaları üretir. Bunlar genellikle hafif piyade birlikleri için uygundur.

# Bozok Güvenlik Şirketi
Güvenlik kaynaklı üretim gerçekleştirirler. Kameralar ve kasalar üretir.

*Bozok Güvenlik Şirketi NT destekli kurulmuş şirkettir.*

# Demirağ Endüstri Şirketi
Kuruluşu Modern Türkiye Cumhuriyetine dayanan köklü bir endüstri şirketidir. Son zamanlarda ürettiği robotik malzemelerle tanınmaktadır.

# Nakamura Mühendislik Şirketi
Kapsamlı inşaat ve imalat şirketidir. Mühendislik ekipmanları ve gerekli kıyafetleri üretir. 

*Ayrıca Nakamura Mühendislik NT gibi şirketler için RCDler ve mühendislik malzemeleri üretirler.*

# Samanyolu Jet Anonim Şirketi
Aya koloni atılmasından itibaren sivil uzay gemiler tasarlayan bir şirkettir.

# Megasus Havacılık
Aya koloni atılmasından itibaren askeri uzay gemileri tasarlayan şirkettir

# DeForest Medikal Şirketi
Eczacılık temelli bir şirkettir. Acil durum şırıngaları ve çeşitli medikal ekipmanlar üretirler.

*İnsanlara destek amaçlı uzay hastaneleri kuran bir şirkettir.*

# HONK Limitet Şirketi
Bir palyaço şirketidir. Palyaço ekipmanları, kıyafetler, sentetik palyaço ayakkabıları ve muzlu turta üretirler! **HONK!**

*Bananium elementini ilk kullanan şirket olmalarıyla ünlüdür.*

# Büyücü Federasyonu
Hah? Büyücüler. Bilirsin işte büyü üretirler sanırım?

# Eight-O Şirketi
Vücut geliştirme aletleri, ağırlık makineleri ve kıyafetler üretirler

# Robust Endüstri Sınırlı Sorumlu Şirketi
Tüketilebilir malzemeler üretirler. Atıştırmalıklar, içecekler ve sigaralar gibi.

# Paralle Limitet Şirketi
Tüketilebilir malzemeler üretirler. Genellikle ürettikleri arasında tatlı çikolatalar yer alır.

# TRT
Bir yayın şirketi olan TRT, Terragov Radyo ve Televizyon kurumudur. Hükümet lehine yaptığı yayınlar ile bilinir.

# Sophronia Yayıncılık Şirketi
Bir yayın şirketi olan Sophronia Yayıncılık, çeşitli yemek ve tarih programları sunmaktadır. Ayrıca aşçı ve kuratör için beaconlar üreten bir şirkettir.

# HHK Kargoculuk Şirketi
Galaksi içerisinde yapmış olduğu kargo teslimleri ile bilinir.

*HHK'nin açılımı bir kargocuya gönderme yapıyor gibi...*
