> ‘’ESENLİKLER! BİZ BÜYÜCÜLER FEDERASYONUNUN BÜYÜCÜLERİYİZ.’’ 
Uzay İstasyonu 08’in tam anlamıyla ve bütünüyle buharlaşmasından önce kaydedilen son mesaj. 



https://github.com/Oynumt1/Psychonaut-Lore/assets/151470732/4fb26b27-eb29-4d55-b397-2254d5bec8c4



***

Uzay Büyücüleri Federasyonu, Spinward Sektöründe faaliyet gösterdiği bilinen ve galaksi çapında olduğundan şüphelenilen bir büyü kullanıcıları kolektifidir. İnsan topluluklarını uzay yolculuğu çağından önce bile etkilediklerine dair abartılı iddialar ortaya atılmıştır. Bu iddialardan bazıları bütün kötü olayları, diktatörleri ve tuhaf rastlantıları büyücü etkisine bağlarlar.

Büyücülerin gerçekten büyü yapıp yapamadıkları hala tartışılan bir konudur. Daha şüpheci olanlar büyünün var olmadığını, büyücülerin yaptığı ve göze büyü olarak görünen şeylerin aslında büyü kılıfındaki komplike teknolojiler olduğu konusunda ısrar ederler. Çoğunluk ise bu tartışmayı umursamaz, zira gerçek olsalar da olmasalar da, bu büyüler işe yaramaktadır ve oldukça etkili bir şekilde ölüme sebep olabilmektedirler.

Son zamanlarda Büyücüler Federasyonu, sadece speküle edilebilen sebepler dolayısıyla Nanotrasen ile Soğuk Savaş benzeri bir durum içerisindedir. Önemli olan, Spinward Sektöründeki istasyonların büyücüler tarafından saldırıya uğruyor olmasıdır, öyle ki büyücülerin mavi şapkaları ve cübbeleri NT çalışanlarının gözünde sendikanın kan kırmızı ekipmanları kadar korkutucu hale gelmiştir. Bu saldırılardan sağ kurtulanlar, büyücülerin neden orada olduğuna ya da (eğer varsa) gerçek amaçlarına dair hiçbir bilgi elde edememişlerdir.

Oldukça gizli bir seviyede, Nanotrasen’in üst düzey çalışanları Büyücüler Federasyonuyla diplomatik temaslarını sürdürmeye çalışmaktadırlar, fakat bu pek az sonuç vermekte, saldırılar diplomatik durumdan tamamen bağımsız olarak artıp azalmaktadır. Büyücüleri bir federasyon olarak toplanmaya iten şeyin ne olduğunu kimse bilmemektedir. Bütün büyü kullanıcıları bu federasyona dahil değildir. Nadiren dostane bir büyücünün bir istasyonda belirip istasyonun misafirperverliğine karşılık olarak hünerlerini gösterdiği ve maceralarının hikayelerini anlattığı da olur. (Fakat bu, NT’nin büyücülere karşı olan tavizsiz ‘’Önce vur, sonra yine vur, son olarak bir daha vur.’’ politikası sebebiyle nadiren gerçekleşmektedir.) Üyelerinin eylemleri sebebiyle Büyücüler Federasyonunun, büyü camiasının en kötülerinin: kaos için yaşayanların ve ellerine geçen her fırsatta büyülü güçlerini sergileme arzusu duyanların toplandığı bir organizasyon olduğundan şüphelenilmektedir.

