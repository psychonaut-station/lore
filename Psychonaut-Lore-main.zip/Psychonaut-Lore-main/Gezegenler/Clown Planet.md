# Clown Planet'in Kökenleri

Clown Planet, uzak bir yıldız sisteminin kenarında yer alan, rengarenk doğası ve esrarengiz yapılarıyla bilinen bir gezegendir. İlk olarak keşfedildiğinde, gezegenin neşeli ve mizah dolu sakinleri - Clownlar - tüm galakside bir fenomen haline geldi. Clownlar, mizahın ve şakanın etrafında dönen kültürleriyle ünlüdür. Ancak, gezegenin karanlık bir geçmişi vardır ve bu geçmiş, galaksinin dört bir yanında yankılanan trajik bir hikayeye sahiptir.

## Honkmother ve Clown Kültürü

Clownlar, Honkmother adında bir tanrıya inanırlar. Honkmother, mizahın, şakanın ve kahkahanın ilahi bir temsilcisidir. Clownlar, onun öğretilerine sadık kalarak, gezegenin her köşesinde mizahı ve neşeyi yaymaya çalışırlar. Honkmother'ın öğretileri, Clownların kültürel ve dini hayatının merkezinde yer alır ve her Clown, Honkmother'ın lütfunu kazanmak için çeşitli ritüel ve törenler gerçekleştirir.

## Adonk Honkler ve Yükselişi

Adonk Honkler, Clown Planet'in en karizmatik ve etkileyici lideri olarak bilinir. Çarpıcı konuşmaları ve güçlü mizah yeteneğiyle halkını etkisi altına aldı. Honkler, Clown Planet'in tarihindeki en popüler lider olarak yükseldi ve Honkmother'ın iradesini yerine getirmek adına büyük bir misyon üstlendiğini iddia etti. Ancak, bu misyon zamanla karanlık bir hal aldı.

Honklerschaft Partisi'ni kurarak, Clownların en saf ve özgün halini koruma iddiasıyla bir hareket başlattı. Honkler, mizahın "saf" biçimini bozan ve Clown kültürüne tehdit olarak gördüğü Mimelara karşı büyük bir nefret geliştirdi.

## Honk Kampları

Adonk Honkler, Mimeların sessizliğini ve farklılıklarını mizahın düşmanı olarak gördü ve onları yok etmeye karar verdi.

Honklerschaft Partisi, Mimeları yakalayarak toplama kamplarına göndermeye başladı. Bu kamplar, "Honk Kampları" olarak adlandırılsa da, gerçekte korkunç gaz odaları ve işkence hücreleriyle doluydu. Milyonlarca Mime, bu kamplarda acımasızca öldürüldü. Gaz odaları, "Honkler Odaları" olarak biliniyordu ve Mimeların burada öldürülmesi, Clownların mizah anlayışının en karanlık ve çarpık yönünü temsil ediyordu.

## Soykırımın Korkunç Yüzü

Adonk Honkler, Mimeları ortadan kaldırma planını büyük bir titizlikle yürüttü. Toplama kamplarında Mimelar, gülme gazı adı verilen özel bir gazla öldürüldü. Bu gaz, Mimeların son nefeslerinde dahi onları trajik bir ironiyle güldürüyordu. Gaz odalarına tıkılan Mimelar, gülme krizleri içinde hayatlarını kaybederken, Honkler ve destekçileri bunu büyük bir zafer olarak kutluyordu.

## Galaksinin Tepkisi

Nanotrasen ve diğer büyük galaktik şirketler, başlangıçta Clown Planet'teki olaylara kayıtsız kaldılar. Ancak, soykırımın dehşet verici detayları gün yüzüne çıktığında, galaksinin dört bir yanında büyük bir tepki dalgası yayıldı. Adonk Honkler ve destekçileri, galaktik mahkemelerde yargılandılar ve bu süreç, galaktik toplumun vicdanında derin izler bıraktı. Honkler, Honkmother'ın iradesini yerine getirdiğini savunsa da, yargı önünde bu savunması kabul görmedi ve en ağır cezaya çarptırıldı.

## Günümüzde Clown Planet

Clown Planet, hala renkli ve neşeli yüzeyinin altında derin yaralar taşımaktadır. Clown Planet, mizahın gücünü ve neşesini koruyarak, galaktik toplumun bir parçası olma yolunda ilerlemektedir.
