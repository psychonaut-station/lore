Hayerofant bazı karşılaşılan yazıtlara göre bundan 1000 yıl önce lavaland içinde yaşanan canlı bir şehir varken, şehrin hemen dışında ki tapınaktaki baş rahibe ait olduğunu görüyoruz. Yazanlara göre rahip zorda olanlara
kol kanat gerer herkese yetişir hatta çok uzak mesafelere bile rahatça ulaşırmış. Bazı felaketler sonucunda rahip korumak birçok şehir sakinini tapınağa toplamış. Daha fazla kişiyi aramaya giderken sopası Hayerofant'a
"bu tapınağı canın pahasına koru" deyip ayrılmış ve belliki gittiği yerden dönememiş. Hayerofant şuan sadece temelleri kalsa dahi hala tapınağı koruyor.
