Lavaland, Nanotrasen'in bugünlere gelmesinde ki en büyük etken. 
Bu gezegenin varlığı yüz yıldan fazladır bilinmesine rağmen felaket koşulları dolayısıyla kimse şimdiye kadar herhangi bir tetkik yapmamıştı. Lavaland'e özel istekle arkeolojik çalışmalar için gelen bir grup nanotrasen çalışanı orada bir kamp kurdu.
Zaman geçtikçe kamp sakinleri etrafı gözlemlerken çıplak gözle bile anlaşılan, başta plazma olmak üzere çeşitli madenin adeta gezegen yüzeyine fışkırdığını Nanotrasen'e geri rapor ettiler, her ne kadar bu mesajdan sonra grupla iletişim kesilse de
Nanotrasen Ummadığını bulup hemen çalışmalara başlamıştı. 2 hafta içinde gezegenin yörüngesinde Uzay İstasyonu 13'ün inşasına başlandı. İstasyon inşa halindeyken yapılan kapsamlı incelemelerde gezegen hakkında daha detaylı bilgiler edinildi. 

Raporlara göre, Lavaland fazlasıyla kararsız tektonik tabakalardan oluşuyor. Sürekli yaşanan depremler yeraltında bulununan magma ve çeşitli değerli madenleri yeryüzüne atıyor. Bu depremlerin oluşturduğu etki sürekli olarak yer tabakasında ki volkanik külü
yukarı kaldırıp tekrar tekrar fırtına misali yağmasına neden oluyor. Tabi bu sadece jeografik zorluklar, Bu cehennemvari gezegende yaşamak üzere uyum sağlamış birçok vahşi ve saldırgan tür bulunmakta. Buraya gelecek olan madencilerin gezegenin besin zincirinde
hayatta kalıp tırmanmaları için zorlu mücadeleler vermesi bekleniyor, sonuçta Nanotrasen'in o madenlere ihtiyacı var.  Ayrıca yapılan son incelemeler bize gösteriyor ki burada birçok garip yapı var. Bunlardan bazıları oldukça eski dururken geri kalanlar sanki
yeni yapılmış gibi duruyor. Tabi nanotrasen bu kalıntılarla ilgilenmediği için araştırma burada kesildi.
