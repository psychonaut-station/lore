İblislerin kralı Kabarcık Sakızı Lavaland'de onunla karşılaşacak kadar şanssız olanları bekliyor. Kabarcık Sakızı cehennemde ki tahtından indirip Lavaland'e getirenin ne olduğunu tam olarak bilemesekte,
biz onun Kabarcık Sakızı olduğunu anlayana kadar 3 tam araştırmacı takımı kaybettik. Sonra geride kalan teknolojik aletleri kurtarma görevinde ise 2 arama kurtarma ekibi kaybedildi. Nanotrasen bu olayla beraber
Kabarcık Sakızı ile ilgili araştırma yapılmasını yasakladı. Madenciler de yerde büyük kan gölleri görmeleri durumunda hemen bölgeden kaçmaları tavsiye ediliyor.
