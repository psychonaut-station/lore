# Çimen Birey'ler Nasıl Oluştu?
Çimen Bireyler, çoğaltıcı bir bitki sayesinde meydana gelen İnsan-Bitki karışımı bir türdür. Bu gizemli bitkiye bir insan, pullusoy veya herhangi bir türün kanını verdikten sonra o bitkiyi hasat ederseniz, (ve o kişi halihazırda ölüyse) Çimen Birey olarak dünyaya geri gelir. Kısacası Çimen Bireyler önceki hayatlarında İnsan veya daha farklı bir tür olarak yaşamışlardır.


# Çimen Birey'lerin Özellikleri
Çimen Bireylerin özelliklerine değinecek olursak, kendileri ışıkların fazla olduğu ortamları severler ve o tarz ortamlarda iyileşirler ve açlıkları giderilir ama çok fazla ışıklı ortamda dururlarsa durum obezliğe yol açar, karanlık ortamlarda ise acıkmaya başlarlar ve zarar görürler. Yiyecek olarak et tüketemezler, sadece bitki tarzı şeyler tüketirler. Son olarak Yapay Zeka'nın asimov yasalarına dahil değildirler ve Yapay Zeka tarafından gözetlenip korunmazlar, Yapay Zeka'ya emir veremezler.

![image](https://github.com/Oynumt1/Psychonaut-Lore/assets/55282547/3428cd24-d905-4f06-bd2f-2225f69aff9f)
